public class Pagamento {
    private double valor;
    private String tipo;
    private boolean status;


    public Pagamento(double valor, String tipo) {
        this.valor = valor;
        boolean status = false;
    }

    public double getValor() {
        return valor;
    }

    public boolean getStatus() {
        return status;
    }

    public String getTipo() {
        return tipo;
    }

    public void processarPagamento(double valor, String tipo) {
        this.status = true;
    }
}
