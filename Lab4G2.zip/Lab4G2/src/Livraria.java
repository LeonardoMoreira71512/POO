import java.util.ArrayList;

public class Livraria {
    private ArrayList<Livro> livros;

    public ArrayList<Livro> getLivros(){
        return this.livros;
    }
    public void fazerTransacao(Transacao transacao) {

    }
}
