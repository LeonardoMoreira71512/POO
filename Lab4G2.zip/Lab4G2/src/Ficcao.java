import java.util.ArrayList;

public class Ficcao extends Livro {
    private ArrayList<String> categorias;

    public Ficcao(double preco, String nome, ArrayList<String> autor, int ano, String editora, String isbn, String fornecedor, ArrayList<String> categorias) {
        super(preco, nome, autor, ano, editora, isbn, fornecedor);
        this.categorias = new ArrayList<>();
    }
}
