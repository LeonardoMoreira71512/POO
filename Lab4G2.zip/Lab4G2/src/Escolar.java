import java.util.ArrayList;

public class Escolar extends Livro {
    private String anoEscolar;

    public Escolar(double preco, String nome, ArrayList<String> autor, int ano, String editora, String isbn, String fornecedor, String anoEscolar){
        super(preco, nome, autor, ano, editora, isbn, fornecedor);
        this.anoEscolar = anoEscolar;
    }
}
