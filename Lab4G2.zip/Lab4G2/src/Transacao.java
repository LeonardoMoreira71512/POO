import java.util.ArrayList;

public class Transacao {
    private int id;
    private ArrayList<Livro> livros;
    private double valorTotal;
    private String data;
    private ArrayList<Pagamento> pagamentos;

    public Transacao(int id, ArrayList<Livro> books, String data) {
        this.id = id;
        this.livros = books;
        this.data = data;
    }

    public int getId() {
        return id;
    }

    public ArrayList<Livro> getBooks() {
        return livros;
    }

    public String getDate() {
        return data;
    }

    static public void venda() {

    }

    static public void devolucao() {

    }
}
