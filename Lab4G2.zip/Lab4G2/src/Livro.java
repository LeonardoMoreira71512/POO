import java.util.ArrayList;

public class Livro {
    private double preco;
    private String nome;
    private ArrayList<String> autor;
    private int ano;
    private String editora;
    private String isbn;
    private String fornecedor;

    public Livro(double preco, String nome, ArrayList<String> autor, int ano, String editora, String isbn, String fornecedor) {

    }

    public ArrayList<String> getAutor() {
        return autor;
    }

    public String getNome() {
        return nome;
    }

    public double getPreco() {
        return preco;
    }

    public int getAno() {
        return ano;
    }

    public String getEditora() {
        return editora;
    }

    public String getIsbn() {
        return isbn;
    }

    public String getFornecedor() {
        return fornecedor;
    }

}
