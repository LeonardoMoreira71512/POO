import java.util.Scanner;
import java.util.ArrayList;

public class Main {
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        int result = 0;
        int sub = 0;
        SegmentoReta reta = new SegmentoReta(new Ponto(sc.nextInt(), sc.nextInt()), new Ponto(sc.nextInt(), sc.nextInt()));
        ArrayList<Molde> moldes = new ArrayList<>();

        int n = sc.nextInt(); //Retangulos
        for (int i = 0; i < n; i++) {
            moldes.add(new Retangulo(new Ponto(sc.nextInt(), sc.nextInt()), new Ponto(sc.nextInt(), sc.nextInt())));
        }

        n = sc.nextInt();
        for (int i = 0; i < n; i++) { // Circulo
            moldes.add(new Circulo(new Ponto(sc.nextInt(), sc.nextInt()), sc.nextInt()));
        }

        n = sc.nextInt();
        for (int i = 0; i < n; i++) { // Triangulos
            moldes.add(new Triangulo(
                    new Ponto(sc.nextInt(), sc.nextInt()),
                    new Ponto(sc.nextInt(), sc.nextInt()),
                    new Ponto(sc.nextInt(), sc.nextInt())));
        }

        for (Molde molde : moldes) {
            if(reta.intersect(molde))
                result++;
        }

        System.out.println(result);
        sc.close();
    }

}
