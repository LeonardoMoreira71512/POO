public class Circulo implements Molde{
    private int raio;
    private Ponto centro;

    public Circulo(Ponto centro, int raio){
        this.centro = centro;
        this.raio = raio;
    }

    public Ponto getCentro() {
        return this.centro;
    }

    public double getRaio() {
        return this.raio;
    }
}
