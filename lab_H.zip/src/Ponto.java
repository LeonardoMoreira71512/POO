public class Ponto {
    private int x;
    private int y;

    public Ponto(int x, int y){
        setX(x); setY(y);
    }

    public void setX(int x) {
        this.x = x;
    }

    public void setY(int y) {
        this.y = y;
    }

    public int getX() {
        return x;
    }

    public int getY() {
        return y;
    }

    public String toString(){
        return "(" + x + "," + y + ")";
    }

    public double dist(Ponto p){
        int dx = getX() - p.getX();
        int dy = getY() - p.getY();
        return Math.sqrt(dx*dx + dy*dy);
    }
}
