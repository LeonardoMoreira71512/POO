public class Triangulo implements Molde{
    public Ponto [] pontos = new Ponto[3];

    public Triangulo(Ponto a, Ponto b, Ponto c){
        this.pontos[0] = a;
        this.pontos[1] = b;
        this.pontos[2] = c;
    }

    public Ponto[] getPontos(){return this.pontos;}
}
