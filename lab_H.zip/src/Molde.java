public interface Molde { }
