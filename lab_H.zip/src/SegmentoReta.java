public class SegmentoReta {
    private Ponto p;
    private Ponto q;
    private double m;
    private double b;

    public SegmentoReta(Ponto p, Ponto q){
        this.p = p;
        this.q = q;
        this.m = (double) (p.getY() - q.getY()) / (double) (p.getX() - q.getX());
        this.b = p.getY() - this.m * p.getX();
    }



    public boolean intersect(Circulo c){
        double dx = q.getX() - p.getX(); //distancia do x dos 2 pontos da reta
        double dy = q.getY() - p.getY(); //distancia do y dos 2 pontos da reta
        double u = ((c.getCentro().getX() - p.getX()) * dx + (c.getCentro().getY() - p.getY()) * dy) / ((dx * dx) + (dy * dy));
        if(u > 1)
            u = 1;
        else if (u < 0)
            u = 0;
        double x = p.getX() + u * dx;
        double y = p.getY() + u * dy;
        dx = x - c.getCentro().getX();
        dy = y - c.getCentro().getY();
        return (c.getRaio() >= Math.sqrt(dx * dx + dy * dy)); //true se raio for maior que a distancia dos 2 pontos da reta
    }

    public boolean intersect(Retangulo r){
        return doIntersect(this.p, this.q, r.getPontos()[1], r.getPontos()[3])
                || doIntersect(this.p, this.q, r.getPontos()[0], r.getPontos()[2]);
    }

    public boolean intersect(Triangulo t){
        return doIntersect(this.p, this.q, t.getPontos()[0], t.getPontos()[1])
                || doIntersect(this.p, this.q, t.getPontos()[0], t.getPontos()[2])
                || doIntersect(this.p, this.q, t.getPontos()[1], t.getPontos()[2]);
    }

    private static boolean onSegment(Ponto a, Ponto b, Ponto c){
        if(b.getX() <= Math.max(a.getX(), c.getX()) //if x do b e menor que o maior valor do x entre a e c
                && b.getX() >= Math.min(a.getX(), c.getX()) //b tem que ser maior que o menor valor entre a e c
                && b.getY() <= Math.max(a.getY(), c.getY()) //b tem que ser menor que o maior valor do y do a e do c
                && b.getY() >= Math.min(a.getY(), c.getY())) //b tem que ser maior que o valor minimo do y entre a e c
        return true;

        return false;
    }

    private static int orientation(Ponto a, Ponto b, Ponto c) {
        int firstAngle = (b.getY() - a.getY()) * (c.getX() - b.getX()); //obtenho altura e comprimento de entre pontos
        int secondAngle = (b.getX() - a.getX()) * (c.getY() - b.getY()); //o mesmo
        int val = firstAngle - secondAngle;

        if (val == 0)
            return 0; // collinear
        return (val > 0) ? 1 : 2; // clock or counterclock wise
    }

    private static boolean doIntersect(Ponto p1, Ponto q1, Ponto p2, Ponto q2) {
        int o1 = orientation(p1, q1, p2);
        int o2 = orientation(p1, q1, q2);
        int o3 = orientation(p2, q2, p1);
        int o4 = orientation(p2, q2, q1);

        if (o1 != o2 && o3 != o4)
            return true;

        if (o1 == 0 && onSegment(p1, p2, q1)) //caso qualquer valor seja colinear e esteja entre 2 pontos dados ent houve interseção
            return true;

        if (o2 == 0 && onSegment(p1, q2, q1))
            return true;

        if (o3 == 0 && onSegment(p2, p1, q2))
            return true;

        if (o4 == 0 && onSegment(p2, q1, q2))
            return true;

        return false;
    }

    public boolean intersect(Molde m) {
        if (m instanceof Retangulo) //instanceof verifica se o objeto é uma instancia da classe
            return intersect((Retangulo) m);
        if (m instanceof Circulo)
            return intersect((Circulo) m);
        if (m instanceof Triangulo)
            return intersect((Triangulo) m);
        return false;
    }

    public Ponto[] getPontos() {
        return new Ponto[] { this.p, this.q };
    }

    public double getDeclive() {
        return this.m;
    }

    public double getOrdenada() {
        return this.b;
    }

    @Override
    public String toString() {
        return this.m + "x " + (this.b < 0 ? " " : "+ ") + this.b + " = y";
    }
}
