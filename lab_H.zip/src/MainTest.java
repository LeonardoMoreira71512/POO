import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class MainTest {
    @Test
    public void intersectRectangle(){
        Ponto p1 = new Ponto(0,0);
        Ponto p2 = new Ponto(5, 5);
        Retangulo rect = new Retangulo(p1, p2);
        Ponto p3 = new Ponto(-10, -10);
        Ponto p4 = new Ponto(10, 10);
        SegmentoReta reta = new SegmentoReta(p3, p4);
        assertTrue(reta.intersect(rect));

        p1 = new Ponto(4, 6);
        p2 = new Ponto(5, 1);
        rect = new Retangulo(p1, p2);
        p3 = new Ponto(0, 3);
        p4 = new Ponto(-21, 11);
        reta = new SegmentoReta(p3, p4);
        assertFalse(reta.intersect(rect));
    }

    @Test
    public void IntersectTriangle(){
        Ponto p1 = new Ponto(14, -3);
        Ponto p2 = new Ponto(5, 14);
        Ponto p3 = new Ponto(5, 7);
        Triangulo triangle = new Triangulo(p1, p2, p3);
        Ponto p4 = new Ponto(3, -14);
        Ponto p5 = new Ponto(14, 9);
        SegmentoReta reta = new SegmentoReta(p3, p4);
        assertTrue(reta.intersect(triangle));

        p1 = new Ponto(14, -3);
        p2 = new Ponto(5, 14);
        p3 = new Ponto(5, 7);
        triangle = new Triangulo(p1, p2, p3);
        p4 = new Ponto(3, -14);
        p5 = new Ponto(14, 9);
        reta = new SegmentoReta(p3, p4);
        assertTrue(reta.intersect(triangle));
    }

    @Test
    public void IntersectCirculo(){
        Ponto p1 = new Ponto(0, 0);
        int raio = 12;
        Circulo circulo = new Circulo(p1, raio);
        Ponto p3 = new Ponto(16, 14);
        Ponto p4 = new Ponto(-14, 2);
        SegmentoReta reta = new SegmentoReta(p3, p4);
        assertTrue(reta.intersect(circulo));

        p1 = new Ponto(15, 7);
        raio = 3;
        circulo = new Circulo(p1, raio);
        p3 = new Ponto(2, 7);
        p4 = new Ponto(4, 8);
        reta = new SegmentoReta(p3, p4);
        assertFalse(reta.intersect(circulo));
    }

}