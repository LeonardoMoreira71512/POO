import java.util.Scanner;

public class test {

    public test(){}

    public static void main(String [] args){
        Scanner sc = new Scanner(System.in);

        int n = sc.nextInt();
        int p = sc.nextInt();
        String string = sc.next();
        int size = string.length();

        while(size ){

        }

        System.out.println(size);
       /*while(string != lastchar){
            int i = 0;
            i++;

        }
        /*public char findlast(String any){
            while(any != lastchar){

            }
        }*/

    }
}
