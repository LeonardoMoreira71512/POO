import java.util.Scanner;

public class Cliente {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		String data = "2022-03-14";
		int convertData = Integer.parseInt(data);
		
		System.out.println(data);
		//Data d = new Data(sc.nextInt(), sc.nextInt(), sc.nextInt());
		//d.add(16);
		//d.bissexto();
		
	}

}
