import java.text.SimpleDateFormat;
import java.time.Instant;
import java.util.Date;
import java.util.Calendar;

public class Data {

		SimpleDateFormat data = new SimpleDateFormat("yyyy-MM-dd");

		private int year, month, day;
		//private int amount;
		boolean bissexto = false;
		
		public Data(int year, int month, int day) {
			this.year = year;
			this.month = month;
			this.day = day;
		}
		
		public String [] dataDiv(String d) {
			String[] data = d.split("-");
			
			int year = Integer.parseInt(data[0]);
			int month = Integer.parseInt(data[1]);
			int day = Integer.parseInt(data[2]);
			
			if(year <= 1875 && month <= 05 && day <= 20) {
				System.out.println("Erro");
				System.exit(0);
			}
			return data;
		}
		
		public boolean bissexto() {
			if(year % 4 == 0 && year % 100 != 0 && year % 400 == 0) {
				return true;
			}
			else
				return false;
		}
		
		public Data add(int dd) {
			/*this.amount = dd;
			int sum = add(day + amount + month + year);*/
			String data;
			//dataDiv()
			Data d1;
			if(day == 31) {
				month++;
				day = 0;
			}
			else if(day == 30) {
				if(month == 04 || month == 06 || month == 9 || month == 11) {
					month++;
					day = 0;
				}
			}
			else if(day == 28 && month == 2) {
				month++;
				day = 0;
			}
			else if(bissexto()) {
				while(month == 2) {
					month++;
			        day = 0;
				}
			}
			return null;
		}
}
