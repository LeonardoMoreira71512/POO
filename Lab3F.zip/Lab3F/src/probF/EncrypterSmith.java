package probF;

public class EncrypterSmith {

	static String encrypt(int n, int p, String message) { //-n - rotateleft ; n - rotateright
		if (n < 0)
			message = leftrotate(message, n * (-1));
		else
			message = rightrotate(message, n);
		
		String enc[] = new String[message.length()];
		String mod = new String();
		
		for (int i = 0; i < message.length(); i++) {
			char c = message.charAt(i);
			c += p;
			enc[i] = String.valueOf(c); //pass the encrypted value to the array
			mod += enc[i]; //pass an array of string to a string
		}
		return mod;
	}

	static String decrypt(int n, int p, String ecryptedMessage) {
		if (n < 0)
			ecryptedMessage = rightrotate(ecryptedMessage, n * (-1));
		else
			ecryptedMessage = leftrotate(ecryptedMessage, n);
		String enc[] = new String[ecryptedMessage.length()];
		String mod = new String();
		for (int i = 0; i < ecryptedMessage.length(); i++) {
			char c = ecryptedMessage.charAt(i);
			c -= p; //desencripta segundo p
			enc[i] = String.valueOf(c); //passa o valor encriptado para o array
			mod += enc[i]; //pass an array of string to a string
		}
		return mod;
	}

	static int[] findkey(String encryptedMessage, String word) {
		String decstr = new String();
		int result[] = new int[2];
		searchKey: {
			for (int n = -9; n <= 9; n++) {
				for (int p = -4; p <= 4; p++) {
					decstr = decrypt(n, p, encryptedMessage).toLowerCase();//deteta "qualquer bug"
					word = decstr.substring(0, 3);
					if (word.equals("bug")) { //key was found, break
						result[0] = n;
						result[1] = p;
						break searchKey;
					}
				}
			}
		}
		return result;
	}

	public static String leftrotate(String str, int n) {
		String ans = str.substring(n) + str.substring(0, n);
		return ans;
	}

	public static String rightrotate(String str, int n) {
		return leftrotate(str, str.length() - n);
	}
}
