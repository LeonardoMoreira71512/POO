package probF;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class EncrypterSmithTests {
	
	@Test
    public void testEncrypt() {
        assertEquals(EncrypterSmith.encrypt(2, 2,"bugIncacheMemory"), "t{dwiKpecejgOgoq");
        assertEquals(EncrypterSmith.encrypt(-3, 0,"ABCDEFGH"), "DEFGHABC");
        assertEquals(EncrypterSmith.encrypt(0, -1,"IBM:111"), "HAL9000");
    }

    @Test
    public void testDecrypt() {
        assertEquals(EncrypterSmith.decrypt(2, 2, "t{dwiKpecejgOgoq"), "bugIncacheMemory");
        assertEquals(EncrypterSmith.encrypt(-2, 0,"GHABCDEF"), "ABCDEFGH");
        assertEquals(EncrypterSmith.encrypt(0, -2,"Z37"), "X15");
    }

    @Test
    public void testFindkey() {
        //assertEquals(EncrypterSmith.findkey("Rd>Qppa@lkqoliibo_", "t{dwiKpecejgOgoq"), );
    }
}
