package probF;
import java.util.Scanner;

public class Craftsman {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int keys[];
		String a = sc.nextLine();
		String str = sc.nextLine();
		String divA[] = a.split(" ");
		int n = Integer.parseInt(divA[0]);
		int p = Integer.parseInt(divA[1]);
		if (n == 0 && p == 0) {
			keys = EncrypterSmith.findkey(str, str);
			n = keys[0];
			p = keys[1];
			System.out.println(EncrypterSmith.decrypt(n, p, str));
		} else {
			System.out.println(EncrypterSmith.encrypt(n, p, str));
		}
	}
}
