import java.util.Scanner;

public class Cliente {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		int numPoints = sc.nextInt();
		double result = 0;
		Ponto A = new Ponto(Double.parseDouble(sc.next()), Double.parseDouble(sc.next()));
		while (numPoints > 1) {		
			Ponto B = new Ponto(Double.parseDouble(sc.next()), Double.parseDouble(sc.next()));
			result += A.dist(B);
			A = B;
			numPoints--;		
		}
	
		System.out.println(String.format("%.2f", result));
		sc.close();
	}
}