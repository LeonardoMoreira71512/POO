import java.util.Scanner;

public class Main{
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        Ponto init = new Ponto(sc.nextInt(), sc.nextInt());
        Ponto f = new Ponto(sc.nextInt(), sc.nextInt());

        int intersection = 0;

        Ponto p1 = new Ponto(0, 0);
        Ponto p2 = new Ponto(0, 0);
        Ponto p3 = new Ponto(0, 0);
        int n = sc.nextInt();
        for(int i = 0; i < n; i++){
            p1.setX(sc.nextInt());
            p1.setY(sc.nextInt());
            p2.setX(sc.nextInt());
            p2.setY(sc.nextInt());
            Retangulo rect = new Retangulo(p1, p2);
        }

        int m = sc.nextInt();
        for(int i = 0; i < m; i++){
            p1.setX(sc.nextInt());
            p1.setY(sc.nextInt());
            Circulo circulo = new Circulo(p1, sc.nextInt());
        }

        int k = sc.nextInt();
        for(int i = 0; i < k; i++){
            p1.setX(sc.nextInt());
            p1.setY(sc.nextInt());
            p2.setX(sc.nextInt());
            p2.setY(sc.nextInt());
            p3.setX(sc.nextInt());
            p3.setY(sc.nextInt());
            Triangulo triangulo = new Triangulo(p1, p2, p3);
        }
    }

}
