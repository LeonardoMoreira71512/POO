public class Molde {
    private String[] figuras;

    public String[] getFiguras() {
        return figuras;
    }
}
