public class Retangulo extends Molde {
    private Ponto[] pontos = new Ponto[4];

    public Retangulo(Ponto min, Ponto max){
        this.pontos[0] = min;
        this.pontos[1] = new Ponto(min.getX(), max.getY());
        this.pontos[2] = max;
        this.pontos[3] = new Ponto(max.getX(), min.getY());
    }

    public Ponto[] getPontos(){
        return this.pontos;
    }
}
