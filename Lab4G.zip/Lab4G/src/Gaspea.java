public class Gaspea {
    private String[] moldes;
    private double reta;

    public String[] getMoldes() {
        return moldes;
    }

    public double getReta() {
        return reta;
    }
}
